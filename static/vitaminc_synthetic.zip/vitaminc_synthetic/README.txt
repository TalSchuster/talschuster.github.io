This dataset is part of the NAACL 2021 paper: "Get Your Vitamin C! Robust Fact Verification with Contrastive Evidence"

Please follow the usage guidelines at https://github.com/TalSchuster/VitaminC
