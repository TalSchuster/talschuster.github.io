This data was processed from here: https://github.com/copenlu/fever-adversarial-attacks

It was used for evaluating VitaminC-trained models. For usage guidelines and details see:
https://github.com/TalSchuster/VitaminC
