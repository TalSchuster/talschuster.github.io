This is the MNLI dataset version processed for the NAACL 2021 paper: "Get Your Vitamin C! Robust Fact Verification with Contrastive Evidence"
NOTE: the evalution data is the "mismatched" version and the test is an identical copy of the dev file (!) since the labels of the real test data are hidden.

More details and guidelines:
MNLI: https://cims.nyu.edu/~sbowman/multinli/
VITAMINC: https://github.com/TalSchuster/VitaminC
