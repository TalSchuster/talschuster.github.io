This dataset is an extension of the FEVER dataset and is part of the EMNLP 2019 paper: "Towards Debiasing Fact Verification Models".
It was used in the NAACL 2021 paper:  "Get Your Vitamin C! Robust Fact Verification with Contrastive Evidence"

More details about the Symmetric dataset: https://github.com/TalSchuster/FeverSymmetric
Please follow the usage guidelines at https://github.com/TalSchuster/VitaminC
