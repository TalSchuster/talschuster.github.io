This is a version of the ANLI dataset from https://github.com/facebookresearch/anli
The format and labels are modified to follow the fact verification format.

This data was used for evaluating VitaminC-trained models. For usage guidelines and details see:
https://github.com/TalSchuster/VitaminC
