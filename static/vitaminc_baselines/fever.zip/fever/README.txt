This is the FEVER dataset version processed for the NAACL 2021 paper: "Get Your Vitamin C! Robust Fact Verification with Contrastive Evidence"

NEI evidence was sampled randomly from the page with the title that ha highest BM25 score with the claim.
dev/ test splits follow the FEVER paper: https://arxiv.org/pdf/1803.05355.pdf

More details and guidelines:
FEVER: https://fever.ai/
VITAMINC: https://github.com/TalSchuster/VitaminC
