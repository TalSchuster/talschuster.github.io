This is the Supports and Refutes examples from FEVER2.0 Fixers Development Dataset, taken from: https://fever.ai/resources.html

This data was used for evaluating VitaminC-trained models. For usage guidelines and details see:
https://github.com/TalSchuster/VitaminC
